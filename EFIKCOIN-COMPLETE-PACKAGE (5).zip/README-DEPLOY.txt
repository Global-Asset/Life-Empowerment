═══════════════════════════════════════════════════════════════
  EFIKCOIN EFC DAPP — DEPLOYMENT GUIDE
  For: efikcoin.xyz
═══════════════════════════════════════════════════════════════

FILES INCLUDED:
  index.html         — Your complete DApp (rename/use as main page)
  efikcoin-dapp-v3.html — Same file with version name

WHAT'S INSIDE:
  ✅ Full Web3 DApp with real BSC contract integration
  ✅ Rotating 3D coin animation with cosmic background
  ✅ Staking (12%, 28%, 45%, 65% APY tiers)
  ✅ Batch Airdrop (uniform + varied)
  ✅ Personal Client Dashboard (localStorage)
  ✅ Wallet Generator + Import (Seed Phrase / Private Key)
  ✅ Portfolio Tracker with live price chart
  ✅ 14-Language auto-detection by IP
  ✅ Social: X, Telegram, WhatsApp, Email
  ✅ Charity Portal link embedded

HOW TO HOST ON efikcoin.xyz:

OPTION 1 — GitHub Pages (FREE, easiest):
  1. Go to github.com → Create new repository named: efikcoin.xyz
  2. Upload index.html to the repository
  3. Go to Settings → Pages → Source: main branch
  4. Your site will be live at: https://yourusername.github.io/efikcoin.xyz
  5. To use efikcoin.xyz domain: add CNAME record pointing to yourusername.github.io

OPTION 2 — Netlify (FREE, drag & drop):
  1. Go to netlify.com → Sign up free
  2. Drag your index.html file onto the Netlify dashboard
  3. It deploys instantly with HTTPS
  4. Add your custom domain efikcoin.xyz in Site Settings → Domain Management

OPTION 3 — cPanel / Traditional Hosting:
  1. Login to your hosting cPanel
  2. Open File Manager
  3. Navigate to public_html folder
  4. Upload index.html
  5. Your site is live at efikcoin.xyz

CONTRACT ADDRESSES (embedded in code):
  EFC Token:     0x677Ce9CBa67f7484ea951a12897CE780cFd8fED1
  Pool Contract: 0xa1DD6C528882Dc19EcCbC967F50bBC121A29630e
  Treasury:      0x676cCf34C191a9D6EFE4B265b84877C619A559d0

SOCIAL LINKS (embedded in code):
  X (Twitter):  https://x.com/efikcoineternal
  Telegram:     https://t.me/efikcoinofficialecosystem
  WhatsApp:     https://chat.whatsapp.com/Fb2tng6Ay2TE8FiRdJIQPG
  Email:        support@efikcoin.xyz
  Charity:      https://efikcoineternalv.github.io/Charity-Empowerment/

Built with ❤️ for Efikcoin Eternal Ecosystem 🕊️
Coin is life, and life is coin.
═══════════════════════════════════════════════════════════════
